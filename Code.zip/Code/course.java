
/**
 * Write a description of class course here.
 * Among all the class, course is the parent class and has two child class. This class has four attributes of different types.
 * first constructor class is created for those attributes with a corresponding access modifers(getter and setter method)
 * At last a display method is created to print output of the attributes.
 * @author (KRISH CHUDAL)
 * @Date ( 18 MAY 2021)
 */
  public class course//this is supercalss, parent class
{
      // variable decleration
      private String courseID;
      private String courseName;
      private String courseLeader;
      private int duration;
      
      //creating parameterized constructors which initialized value to instance variables of Course class 
      course(String courseID,String courseName,int duration)//creating constructor 
        {
            this.courseID=courseID;//this. is reference variables which refers instance variable
            this.courseName=courseName;
            this.courseLeader="";
            this.duration=duration;
        }

      //getter and Setter method of Course class's variable (starting)
      public void setcourseID(String courseID)
        {
            this.courseID=courseID;
        }
        
        
        public String getcourseID()
        {
            return courseID;
        }
      
      
      public void setcourseName(String courseName)
        {
            this.courseName=courseName;
        }
        
        
        public String getcourseName()
        {
            return courseName;
                    }
        
       
      public void setcourseLeader(String courseLeader)
        {
            this.courseLeader=courseLeader;
        }
        
        
      public String getcourseLeader()
        {
            return courseLeader;
        }
       
      public void setduration(int duration)
        {
            this.duration=duration;
        }  
      
      public int getduration()
        {
            return duration;
        }
            //end of accessor method (get and set)
        
        //Main method or Display method to display the output result
        void display()
        {
            System.out.println("The Course ID =" + courseID);
            System.out.println("The Course Name =" + courseName);
            System.out.println("The Duration =" + duration);
            if(courseLeader!=""){
            System.out.println("The Course Leader =" + courseLeader);
        }
        
    }
}
