
/**
 * Write a description of class nonAcademicCourse here. This is child class of
 * course class.It has ten attributes. Constructor class is created with
 * parameters of that class of different types of access modifiers. In the
 * constructor super class varibles are called. getter and setter method are
 * created and two methods are created. Finally a display method is created to
 * print the output.
 * 
 * @author (KRISH CHUDAL)
 * @version (18 MAY 2021)
 */
public class nonAcademicCourse extends course {
    private String instructorName;// attributes or variables decleration
    private String startDate;
    private String completionDate;
    private String examDate;
    private String prerequisite;
    private boolean isRegistered;
    private boolean isRemoved;

    nonAcademicCourse(String courseID, String courseName, int duration, String prerequisite) {
        super(courseID, courseName, duration);// calling super class variables
        this.prerequisite = prerequisite;
        this.startDate = "";
        this.completionDate = "";
        this.examDate = "";
        this.isRegistered = false;
        this.isRemoved = false;
    }

    // getter and setter method to deceleration the variable values

    public String getinstructorName() {
        return instructorName;
    }

    public void setstartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getstartingDate() {
        return startDate;
    }

    public void setcompletionDate(String completionDate) {
        this.completionDate = completionDate;
    }

    public String getcompletionDate() {
        return completionDate;
    }

    public void setexamDate(String examDate) {
        this.examDate = examDate;
    }

    public String getexamDate() {
        return examDate;
    }

    public void setprerequisite(String prerequisite) {
        this.prerequisite = prerequisite;
    }

    public String getprerequisite() {
        return prerequisite;
    }

    public void setisRegistered(boolean isRegistered) {
        this.isRegistered = isRegistered;
    }

    public boolean getisRegistered() {
        return isRegistered;
    }

    public void setisRemoved(boolean isRemoved) {
        this.isRemoved = isRemoved;
    }

    public boolean getisRemoved() {
        return isRemoved;
    }

    public void setinstructorName(String instructorName)// method to set new instructor name if non-registerd and give
                                                        // suitable output if already been registerd.
    {
        this.instructorName = instructorName;
    }

    public void register(String leaderName, String instructorName, String startingDate, String CompletionDate,
            String examDate) {
        if (this.isRegistered == false) {
            this.instructorName = instructorName;
            this.isRegistered = true;
            this.startDate=startingDate;
            this.completionDate=CompletionDate;
            this.examDate=examDate;

        } else {
            System.out.println("This selected course has already been registered");
        }

    }

    public void removed() {
        if (this.isRemoved == true) {
            System.out.println("Dear Teacher/student non academic course has been removed.");
        } else {
            instructorName = "";
            startDate = "";
            completionDate = "";
            examDate = "";
            isRegistered = false;
            isRemoved = true;
        }
    }

    public void display() {
        super.display();// calling super class display method three attributes output from class course
        if (isRegistered == true) {
            System.out.println("The instructorName is " + instructorName);
            System.out.println("The startingDate is" + startDate);
            System.out.println("The completionDate is " + completionDate);
            System.out.println("THe examDate is " + examDate);
            System.out.println("The prerequisite is " + prerequisite);

        }
    }
}