/**
 * Write a description of class academicCourse here.
 *  This is child class of course class.It has seven attributes.
 *  Constructor class is created with parameters of that class of different types of access modifiers.
 *  In the constructor super class varibles are called.
 *  getter and setter method are created and a method is created to check the status of joining.
 *  Finally a display method is created to print the output.
 * @author (KRISH CHUDAL)
 * @version (18 MAY 2021)
*/
public class academicCourse extends course // loading of super class in sub calss or parent class in child class

{    //instant variable decleration
    private String lecturerName;
    private String level;
    private String credit;
    private String startingDate;
    private String completionDate;
    private int numberOfAssessments;
    private boolean isRegistered;


    //creating constructor class
    public academicCourse(String courseID,String courseName,int duration,int numberOfAssessments,String level,String credit)
    {
        super(courseID,courseName,duration);
        this.startingDate="";
        this.completionDate="";
        this.lecturerName="";
        this.level=level;
        this.credit=credit;
        this.numberOfAssessments=numberOfAssessments;
        this.isRegistered=false;
   
    }
    
    public String getlecturerName()
    {
        return lecturerName;
    }
    
        
    public String getlevel()
    {
        return level;
    }
    

    public String getcredit()
    {
        return credit;
    }
    

    
    public String getstartingDate()
    {
        return startingDate;
    }
    
        

    public String getcompletionDate()
    {
        return completionDate;
    }
    
    
        
    public int getnumberOfAssessments()
    {
        return numberOfAssessments;
    }
    
    public boolean getisRegistered()
    {
        return isRegistered;
    }

    /**creating the set method to change the value accordingly as to the condition*/
    public void setlecturerName(String lecturerName)
        {
            this.lecturerName=lecturerName;
        }
    
     
     public void setnumberOfAssessments(int numberOfAssessments)
        {
           this.numberOfAssessments=numberOfAssessments;
        }
    
    public void register(String courseLeader,String lecturerName,String startingDate,String completionDate)   
    {
      if (isRegistered)
      {
          System.out.println("Name of the lecturer is" + lecturerName);
          System.out.println("Starting date" + startingDate);
          System.out.println("completiondate" + completionDate);
      }
      else
      {
          super.setcourseLeader(courseLeader);
          this.lecturerName =lecturerName;
          this.startingDate =startingDate;
          this.completionDate =completionDate;
          this.isRegistered = true;
      }
             
    } 
    
    public void display()//this the main method of this class to display.
    {
        super.display();
            if(isRegistered==true)
            {
            System.out.println("The registered lecturerName is: " + lecturerName);//calling of getters method, getting the value.
            System.out.println("The level is:" + level);
            System.out.println("The credit is:" + credit);
            System.out.println("The StartingDate is:" + this.startingDate);
            System.out.println("The completionDate is:" + this.completionDate);
            
            }
    }
}