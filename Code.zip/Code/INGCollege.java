
/**
 * Write a description of class INGCollege here.
 *This is the graphical user interface of INCollege class.
 *This takes input from user and provides,display appropriate message on the condition.
 *This class INGCollege uses previous class Course and its child class for input gaining.
 *
 * @Krish Chudal
 * @7 Aug 2021
 */

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import java.awt.Font;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class INGCollege implements ActionListener {
    private JFrame frame;
    private JPanel panel;

    private JButton jb, bb, ee, kk, ll, xx, yy, zz;
    private JComboBox<String> cb;
    private JLabel title, text, text1, text2, text3, text4, text5, text6, text7, text8, text9, text10, tx, tx1, tx2,
            tx3, tx6, tx7, tx8, tx9, tx10, tx11;
    private JTextField field, field1, field3, field4, field5, field6, field7, field8, field9, field10, fl, fl1, fl2,
            fl3, fl4, fl6, fl7, fl8, fl9, fl10, fl11;

    academicCourse obj;
    academicCourse obj1;
    nonAcademicCourse obj2;
    nonAcademicCourse obj3;
    nonAcademicCourse obj4;
    academicCourse obj5;
    nonAcademicCourse obj6;

    ArrayList<course> all = new ArrayList<>();

    public String getField() {
        return field.getText();
    }

    public String getField1() {
        return field1.getText();
    }

    public String getField3() {
        return field3.getText();
    }

    public String getField4() {
        return field4.getText();
    }

    public String getField5() {
        return field5.getText();
    }

    public String getField6() {
        return field6.getText();
    }

    public String getField7() {
        return field7.getText();
    }

    public String getField8() {
        return field8.getText();
    }

    public String getField9() {
        return field9.getText();
    }

    public String getField10() {
        return field10.getText();
    }

    public String getFl() {
        return fl.getText();
    }

    public String getFl1() {
        return fl1.getText();
    }

    public String getFl2() {
        return fl2.getText();
    }

    public String getF3l() {
        return fl3.getText();
    }

    public String getFl4() {
        return fl4.getText();
    }

    public String getFl6() {
        return fl6.getText();
    }

    public String getFl7() {
        return fl7.getText();
    }

    public String getFl8() {
        return fl8.getText();
    }

    public String getFl9() {
        return fl9.getText();
    }

    public String getFl10() {
        return fl10.getText();
    }

    public String getFl11() {
        return fl11.getText();
    }

    public void m1() {
        frame = new JFrame();// creating JPanel
        frame.setVisible(true);
        frame.setTitle("INGCollege");
        frame.setSize(1200, 850);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setBackground(Color.GREEN);// setting frame background

        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.GRAY);
        frame.add(panel);

        title = new JLabel();
        title.setText("AcademicCourse");
        Font f = new Font("Times New Roman", Font.PLAIN, 42);
        title.setBounds(450, 30, 370, 50);

        title.setFont(f);
        panel.add(title);// adding title to panel

        text = new JLabel();
        text.setText("CourseID :");
        text.setBounds(90, 62, 200, 120);
        panel.add(text);

        field = new JTextField();
        field.setBounds(240, 108, 180, 30);
        panel.add(field);

        text1 = new JLabel();
        text1.setText("CourseName :");
        text1.setBounds(740, 62, 200, 120);
        panel.add(text1);

        field1 = new JTextField();
        field1.setBounds(850, 108, 180, 30);
        panel.add(field1);

        text3 = new JLabel();
        text3.setText("Duration :");
        text3.setBounds(90, 145, 200, 30);
        panel.add(text3);

        field3 = new JTextField();
        field3.setBounds(240, 150, 180, 30);
        panel.add(field3);

        text2 = new JLabel();
        text2.setText("Level: ");
        text2.setBounds(740, 145, 180, 30);
        panel.add(text2);

        String Level[] = { "Select", "Level 1", "Level 2", "Level 3" };
        cb = new JComboBox<>(Level);
        cb.setBounds(850, 145, 185, 35);
        panel.add(cb);

        text4 = new JLabel();
        text4.setText("Credit: ");
        text4.setBounds(90, 140, 200, 120);
        panel.add(text4);

        field4 = new JTextField();
        field4.setBounds(240, 190, 180, 30);
        panel.add(field4);

        text10 = new JLabel();
        text10.setText("No.Of Assesment");
        text10.setBounds(740, 140, 200, 120);
        panel.add(text10);

        field10 = new JTextField();
        field10.setBounds(850, 185, 180, 30);
        panel.add(field10);

        jb = new JButton("Add for Academic Course");
        jb.setBounds(740, 220, 300, 40);
        jb.setBackground(Color.lightGray);
        jb.setBorder(BorderFactory.createLineBorder(Color.white));
        jb.addActionListener(this);
        panel.add(jb);

        text5 = new JLabel();
        text5.setText("Course ID: ");
        text5.setBounds(90, 200, 200, 120);
        panel.add(text5);

        field5 = new JTextField();
        field5.setBounds(240, 245, 180, 30);
        panel.add(field5);

        text6 = new JLabel();
        text6.setText("Course Leader :");
        text6.setBounds(740, 210, 200, 120);
        panel.add(text6);

        field6 = new JTextField();
        field6.setBounds(850, 263, 180, 30);
        panel.add(field6);

        text7 = new JLabel();
        text7.setText("Lecturer Name: ");
        text7.setBounds(90, 235, 200, 120);
        panel.add(text7);

        field7 = new JTextField();
        field7.setBounds(240, 279, 180, 30);
        panel.add(field7);

        text8 = new JLabel();
        text8.setText("Starting Date :");
        text8.setBounds(740, 245, 200, 120);
        panel.add(text8);

        field8 = new JTextField();
        field8.setBounds(850, 297, 180, 30);
        panel.add(field8);

        text9 = new JLabel();
        text9.setText("Completion Date :");
        text9.setBounds(90, 270, 200, 120);
        panel.add(text9);

        field9 = new JTextField();
        field9.setBounds(240, 315, 180, 30);
        panel.add(field9);

        bb = new JButton("Register Acacemic Course");
        bb.setBounds(740, 333, 300, 40);
        bb.setBackground(Color.lightGray);
        bb.setBorder(BorderFactory.createLineBorder(Color.white)); 
        bb.addActionListener(this);
        panel.add(bb);

        /**
         * Non - Academic Course section
         */

        title = new JLabel();
        title.setText("Non-AcademicCourse");
        Font fn = new Font("Times New Roman", Font.PLAIN, 35);
        title.setFont(fn);
        title.setBounds(470, 370, 400, 50);

        panel.setFont(fn);
        panel.add(title);

        tx = new JLabel();
        tx.setText("CourseID :");
        tx.setBounds(90, 395, 200, 120);
        panel.add(tx);

        fl = new JTextField();
        fl.setBounds(240, 440, 180, 30);
        panel.add(fl);

        tx1 = new JLabel();
        tx1.setText("CourseName :");
        tx1.setBounds(740, 395, 200, 120);
        panel.add(tx1);

        fl1 = new JTextField();
        fl1.setBounds(850, 440, 180, 30);
        panel.add(fl1);

        tx2 = new JLabel();
        tx2.setText("Durartion: ");
        tx2.setBounds(90, 474, 180, 30);
        panel.add(tx2);

        fl3 = new JTextField();
        fl3.setBounds(240, 475, 180, 30);
        panel.add(fl3);

        tx3 = new JLabel();
        tx3.setText("Prerequisite: ");
        tx3.setBounds(740, 430, 200, 120);
        panel.add(tx3);

        fl4 = new JTextField();
        fl4.setBounds(850, 475, 180, 30);
        panel.add(fl4);

        ee = new JButton("Add for Non-Academic Course");
        ee.setBounds(740, 515, 300, 40);
        ee.setBackground(Color.lightGray);
        ee.setBorder(BorderFactory.createLineBorder(Color.white));
        ee.addActionListener(this);
        panel.add(ee);

        tx6 = new JLabel();
        tx6.setText("Course ID: ");
        tx6.setBounds(90, 525, 200, 120);
        panel.add(tx6);

        fl6 = new JTextField();
        fl6.setBounds(240, 565, 180, 30);
        panel.add(fl6);

        tx7 = new JLabel();
        tx7.setText("Course Leader : ");
        tx7.setBounds(740, 525, 200, 120);
        panel.add(tx7);

        fl7 = new JTextField();
        fl7.setBounds(850, 565, 180, 30);
        panel.add(fl7);

        tx8 = new JLabel();
        tx8.setText("Instructor Name : ");
        tx8.setBounds(90, 555, 200, 120);
        panel.add(tx8);

        fl8 = new JTextField();
        fl8.setBounds(240, 600, 180, 30);
        panel.add(fl8);

        tx9 = new JLabel();
        tx9.setText("Start Date :");
        tx9.setBounds(740, 555, 200, 120);
        panel.add(tx9);

        fl9 = new JTextField();
        fl9.setBounds(850, 600, 180, 30);
        panel.add(fl9);

        tx10 = new JLabel();
        tx10.setText("Completion Date  :");
        tx10.setBounds(90, 590, 200, 120);
        panel.add(tx10);

        fl10 = new JTextField();
        fl10.setBounds(240, 635, 180, 30);
        panel.add(fl10);

        tx11 = new JLabel();
        tx11.setText("Exam Date  :");
        tx11.setBounds(740, 590, 200, 120);
        panel.add(tx11);

        fl11 = new JTextField();
        fl11.setBounds(850, 635, 180, 30);
        panel.add(fl11);

        kk = new JButton("Register Non-Academic Course");
        kk.setBounds(740, 680, 300, 40);
        kk.setBackground(Color.lightGray);
        kk.setBorder(BorderFactory.createLineBorder(Color.white));
        kk.addActionListener(this);
        panel.add(kk);

        ll = new JButton("Remove Non-Academic Course");
        ll.setBounds(465, 750, 230, 40);
        ll.setBackground(Color.lightGray);
        ll.setBorder(BorderFactory.createLineBorder(Color.white));
        ll.addActionListener(this);
        panel.add(ll);

        xx = new JButton("Display Academic");
        xx.setBounds(240, 350, 180, 40);
        xx.setBackground(Color.lightGray);
        xx.setBorder(BorderFactory.createLineBorder(Color.white));
        xx.addActionListener(this);
        panel.add(xx);

        zz = new JButton("Display Non-academic");
        zz.setBounds(90, 750, 180, 40);
        zz.setBackground(Color.lightGray);
        zz.setBorder(BorderFactory.createLineBorder(Color.white));
        zz.addActionListener(this);
        panel.add(zz);

        yy = new JButton("Clear");
        yy.setBounds(850, 750, 180, 40);
        yy.setBackground(Color.lightGray);
        yy.setBorder(BorderFactory.createLineBorder(Color.white));
        yy.addActionListener(this);
        panel.add(yy);

        frame.setResizable(false);
        frame.setLayout(null);
        frame.setVisible(true);
    }

    /**
     * Methods initializing this method is created to initialize the working
     * mechanism of the buttons.
     */
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == jb) {
            addForAcademicCourse();
        }

        else if (e.getSource() == bb) {
            registerAcademicCourse();
        }

        else if (e.getSource() == ee) {
            addForNonAcademicCourse();
        }

        else if (e.getSource() == kk) {
            registerNonAcademicCourse();
        }

        else if (e.getSource() == ll) {
            removeNonAcademicCourse();
        }

        else if (e.getSource() == xx) {
            displayAcademic();
        } 
        else if (e.getSource() == yy) {
            Clear();
        }
         else if (e.getSource() == zz) {
            displayNonAcademic();
        }
    }

    /**
     * This is a method of acadamic course, it describes the working function of add
     * courseID for academic course buttom when the button is pressed. and displays
     * appropriate message on the condition when the button is pressed
     */
    public void addForAcademicCourse() {
        String courseID = getField();
        String courseName = getField1();
        String durationString = getField3();
        String level = (cb.getSelectedItem()).toString();
        String credit = getField4();
        String numberOfAssessmentsString = getField10();
        int duration, numberOfAssessments;
        boolean isDuplicateCourseID = false;
        if (courseID.equals("") || courseName.equals("") || durationString.equals("") || level.equals("")
                || credit.equals("") || numberOfAssessmentsString.equals("")) {
            JOptionPane.showMessageDialog(null, "Please fill all the fields.", "Empty Fields", 1);
            return;
        } else {
            if (all.isEmpty()) {
                isDuplicateCourseID = true;
            } else {
                for (course obj : all) {
                    if (obj.getcourseID().equals(courseID)) {
                        JOptionPane.showMessageDialog(null, "The course is already added.", "Duplicate Course", 2);
                        return;
                    } else {
                        isDuplicateCourseID = true;
                    }
                }
            }
            try {
                duration = Integer.parseInt(durationString);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please fill a number in duration field.", "Value Miss-matched", 1);
                return;
            }
            try {
                numberOfAssessments = Integer.parseInt(numberOfAssessmentsString);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please fill a number in number of assessments field.",
                        "Value Miss-matched", 1);
                return;
            }
            if (isDuplicateCourseID) {
                all.add(new academicCourse(courseID, courseName, duration, numberOfAssessments, level, credit));
                JOptionPane.showMessageDialog(null, "The course is added sucessfully.", "Addition Successs", 1);
                return;
            }
        }
    }

    /**
     * This method is used to register academic course it describes what and how a
     * staff is appointed on button click and what to do in wrong input.
     */
    public void registerAcademicCourse() {
        String courseID = getField5();
        String courseLeader = getField6();
        String lecturerName = getField7();
        String startingDate = getField8();
        String completionDate = getField9();
        boolean flag = false;
        if (courseID.equals("") || courseLeader.equals("") || lecturerName.equals("") || startingDate.equals("")
                || completionDate.equals("")) {
            JOptionPane.showMessageDialog(null, "Please fill all the fields.", "Empty Fields", 1);
            return;
        } else {
            if (all.isEmpty()) {
                JOptionPane.showMessageDialog(null, "The list is empty.\n Please add a course before registering",
                        "Empty list", 1);
                return;
            } else {
                for (course obj : all) {
                    if (obj.getcourseID().equals(courseID)) {
                        if (obj instanceof academicCourse) {
                            academicCourse ac = (academicCourse) obj;
                            if (ac.getisRegistered()) {
                                JOptionPane.showMessageDialog(null, "The " + courseID + " is already registered.",
                                        "Duplicate registration", 1);
                                return;
                            } else {
                                ac.register(courseLeader, lecturerName, startingDate, completionDate);
                                JOptionPane.showMessageDialog(null, "The course is registered sucessfully.",
                                        "Registration success", 1);
                                return;
                            }
                        }
                    } else {
                        flag = true;
                    }
                }
            }
            if (flag) {
                JOptionPane.showMessageDialog(null, "The " + courseID + " is not available", "Invalid course", 1);
            }
        }
    }

    /**
     * This method is used to add non Academic Course It add non academic course on
     * button click and also displays error message when wron input are filled try
     * and catch block are used for catching exception
     */
    public void addForNonAcademicCourse() {
        String courseID = getFl();
        String courseName = getFl1();
        String durationString = getF3l();
        String prerequisite = getFl4();
        boolean isDuplicateCourseID = false;
        int duration;
        if (courseID.equals("") || courseName.equals("") || durationString.equals("") || prerequisite.equals("")) {
            JOptionPane.showMessageDialog(null, "Please fill all the fields.", "Empty Fields", 1);
            return;
        } else {
            if (all.isEmpty()) {
                isDuplicateCourseID = true;
            } else {
                for (course obj : all) {
                    if (obj.getcourseID().equals(courseID)) {
                        JOptionPane.showMessageDialog(null, "The " + courseID + " is already added.",
                                "Duplicate Course", 2);
                        return;
                    } else {
                        isDuplicateCourseID = true;
                    }
                }
            }
            try {
                duration = Integer.parseInt(durationString);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please fill a number in duration field.", "Value Miss-matched", 1);
                return;
            }
            if (isDuplicateCourseID) {
                all.add(new nonAcademicCourse(courseID, courseName, duration, prerequisite));
                JOptionPane.showMessageDialog(null, "The " + courseID + " is added sucessfully.", "Addition Successs",
                        1);
                return;
            }
        }
    }

    // register non academic button method
    /**
     * This method to register non academic course
     */
    public void registerNonAcademicCourse() {

        String courseID = getFl6();
        String courseLeader = getFl7();
        String instructorName = getFl8();
        String startingDate = getFl9();
        String completionDate = getFl10();
        String examDate = getFl11();
        boolean flag = false;
        if (courseID.equals("") || courseLeader.equals("") || instructorName.equals("") || startingDate.equals("")
                || completionDate.equals("") || examDate.equals("")) {
            JOptionPane.showMessageDialog(null, "Please fill all the fields.", "Empty Fields", 1);
            return;
        } else 
            if (all.isEmpty()) {
                JOptionPane.showMessageDialog(null, "The list is empty.\n Please add a course before registering",
                        "Empty list", 1);
                return;
            } else {
                for (course obj : all) {
                    if (obj.getcourseID().equals(courseID)) {
                        if (obj instanceof nonAcademicCourse) {
                            nonAcademicCourse nac = (nonAcademicCourse) obj;
                            if (nac.getisRegistered()) {
                                JOptionPane.showMessageDialog(null, "The course is already registered.",
                                        "Duplicate registration", 1);
                                return;
                            } else {
                                if (nac.getisRegistered()) {
                                JOptionPane.showMessageDialog(null, "The course is already registered.",
                                        "Duplicate registration", 1);
                                return;
                            }
                        }
                    } else {

                    }
                }
            }
            if (flag) {
                JOptionPane.showMessageDialog(null, "The " + courseID + " is no available", "Invalid course", 1);
            }
        }
    }

    // removeNonAcademicCourse

    /**
     * This method is for removeNonAcademicCourse
     */
public void removeNonAcademicCourse() {
         String courseID = getFl();
         boolean flag = false;
        if (all.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "The list is empty.\n Please add and register a course before removing.", "Empty list", 1);
            return;
        } else {
            for (course obj : all) {
                if (obj.getcourseID().equals(courseID)) {
                    nonAcademicCourse nac = (nonAcademicCourse) obj;
                    if (nac.getisRemoved()) {
                        JOptionPane.showMessageDialog(null, "The course is already removed.", "Course not available",
                                1);
                        return;
                    } else {
                        nac.removed();
                        JOptionPane.showMessageDialog(null, "The course is removed sucessfully.", "Removal success", 1);
                        return;
                    }
                }
            }
            if (flag) {
                JOptionPane.showMessageDialog(null, "The " + courseID + " is no available", "Invalid course", 1);
            }
        }    
}

    /**
     * this is display method for displaying all the input is simply gain the values
     * from the text fields that are stored
     */
    public void displayAcademic() {
        String courseID = getField();
        boolean flag = false;
        if (all.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "The list is empty.\n Please add and register a course before displaying.", "Empty list", 1);
            return;
        } else {
            for (course obj : all) {
                if (obj.getcourseID().equals(courseID)) {
                    if (obj instanceof academicCourse) {
                        if (obj instanceof academicCourse){
                            academicCourse ac = (academicCourse) obj;
                            if (ac.getisRegistered()){
                                ac.display();
                                return;
                            }else{
                                ac.display();
                                return;
                            }
                        }
                    }
                }
            }
            if (flag) {
                JOptionPane.showMessageDialog(null, "The " + courseID + " is no available", "Invalid course", 1);
            }
        }
    }

    public void displayNonAcademic() {
        String courseID = getFl();
        boolean flag = false;
        
        if (all.isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "The list is empty.\n Please add and register a course before displaying.", "Empty list", 1);
            return;
        } else {
            for (course obj : all) {
                if (obj.getcourseID().equals(courseID)) {
                    if (obj instanceof nonAcademicCourse) {
                        nonAcademicCourse nac=(nonAcademicCourse) obj;
                        if (nac.getisRegistered()) {
                            nac.display();
                            return;
                        } else {
                            nac.display();
                            return;
                        }
                    }
                }
            }
            if (flag) {
                JOptionPane.showMessageDialog(null, "The " + courseID + " is no available", "Invalid course", 1);
            }
        }
    }

    /**
     * this method is created to clear each and every filled text fields
     */
    public void Clear() {
        field=new JTextField();
        field.setText("");
        field1= new JTextField();
        field1.setText("");
        field3=new JTextField();
        field3.setText("");
        field4=new JTextField();
        field4.setText("");
        field6=new JTextField();
        field6.setText("");
        field7=new JTextField();
        field7.setText("");
        field8=new JTextField();
        field8.setText("");
        field9=new JTextField();
        field9.setText("");
        field10=new JTextField();
        field10.setText("");

        fl=new JTextField();
        fl.setText("");
        fl1=new JTextField();
        fl1.setText("");
        fl3=new JTextField();
        fl3.setText("");
        fl4=new JTextField();
        fl4.setText("");
        fl6=new JTextField();
        fl6.setText("");
        fl7=new JTextField();
        fl7.setText("");
        fl8=new JTextField();
        fl8.setText("");
        fl9=new JTextField();
        fl9.setText("");
        fl10=new JTextField();
        fl10.setText("");
        fl11=new JTextField();
        fl11.setText("");
        JOptionPane.showMessageDialog(frame, "All the text fields has been cleared!");
        cb.setSelectedIndex(0);
    }

    /**
     * this is a main method
     */
    public static void main(String[] args) {
        INGCollege IN = new INGCollege();
        IN.m1();
    }
}